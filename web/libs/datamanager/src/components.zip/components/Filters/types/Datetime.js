import { DateFields } from "./Date";

export const DatetimeFilter = [...DateFields({ time: true })];
