import { Dropdown } from "./DropdownComponent";
import { DropdownTrigger } from "./DropdownTrigger";

Dropdown.Trigger = DropdownTrigger;

export { Dropdown };
